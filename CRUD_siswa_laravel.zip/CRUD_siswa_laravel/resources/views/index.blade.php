<!DOCTYPE html>
<html>
<head>
	<title>CRUD Tabel Siswa</title>
	<link rel="stylesheet" type="text/css" href="{{ asset('/css/app.css') }}">
	<script type="text/javascript" src="{{ asset('/js/app.js') }}"></script>
</head>
<body>

	<div class="container">
		<div class="card">
			<div class="card-body">

					<style type="text/css">
						.pagination li{
							float: left;
							list-style-type: none;
							margin:5px;
						}
					</style>

					<h2 class="text-center">CRUD Tabel Siswa</h2>
					
					<h3>Data Siswa</h3>

					<h6>Cari Data Siswa :</h6>

					<form action="/siswa/cari" method="GET" class="form-inline">
						<input  class="form-control" type="text" name="cari" placeholder="Cari Siswa .." value="{{ old('cari') }}">
						<input class="btn btn-primary ml-3" type="submit" value="&#x1F50D Cari">
					</form>

					<br>
					<a class="btn btn-primary ml-1" onclick="javascript:if(confirm('Apakah anda yakin menambah data ?') == true) {window.location.href='/siswa/tambah'} ">+ Tambah Data Siswa</a>

					<br>
					<br>
					
					<table class="table table-bordered">
						<tr>
							<th>Nama</th>
							<th>Nomor HP</th>
							<th>Email</th>
							<th>Action</th>
						</tr>
						@foreach($siswa as $s)
						<tr>
							<td>{{$s->nama}}</td>
							<td>{{$s->no_hp}}</td>
							<td>{{$s->email}}</td>
							<td>
								<input type="button" value="&#9998; Edit" class="btn btn-warning btn-sm" onclick="javascript:if(confirm('Apakah anda yakin edit data ?') == true) {window.location.href='/siswa/edit/{{$s->id_siswa}}'} " />
								<input type="button" value="&times; Delete" class="btn btn-danger btn-sm" onclick="javascript:if(confirm('Apakah anda yakin hapus data ?') == true) {window.location.href='/siswa/hapus/{{$s->id_siswa}}'} " />
							</td>
						</tr>
						@endforeach
					</table>

					<br/>
					Halaman : {{ $siswa->currentPage() }} <br/>
					Jumlah Data : {{ $siswa->total() }} <br/>
					Data Per Halaman : {{ $siswa->perPage() }} <br/>
				 
				 
					{{ $siswa->links() }}
			</div>
		</div>
	</div>

</body>
</html>