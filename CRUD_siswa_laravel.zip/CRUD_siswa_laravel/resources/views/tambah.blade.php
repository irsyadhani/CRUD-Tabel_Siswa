<!DOCTYPE html>
<html>
<head>
	<title>Menambah Data Siswa</title>
	<link rel="stylesheet" type="text/css" href="{{ asset('/css/app.css') }}">
	<script type="text/javascript" src="{{ asset('/js/app.js') }}"></script>
</head>
<body>
	<div class="container" id="content_sidebar">
		<div class="card">
			<div class="card-body">
		
				<h3 class="text-center">Tambah Data Siswa</h3>		

				<br>
				<br>

				<form action="/siswa/store" method="post" class="form-horizontal">
					{{csrf_field()}}
					
					<div class="form-group">
						<label class="control-label col-sm-2" for="nama">Nama Siswa:</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" required="required" name="nama">
						</div>
					</div>

					<div class="form-group">
						<label class="control-label col-sm-2" for="no_hp">Nomor HP:</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" required="required" name="no_hp">
						</div>
					</div>

					<div class="form-group">
						<label class="control-label col-sm-2" for="email">Email:</label>
						<div class="col-sm-10">
							<input type="email" class="form-control" required="required" name="email">
						</div>
					</div>
					<button type="submit" class="btn btn-primary">Simpan</button>
					<button type="reset" class="btn btn-secondary">Reset</button>
							<a href="/siswa"><button type="button" class="btn btn-danger">Kembali</button></a>
					
				</form>
			</div>
		</div>		
	</div>
</body>
</html>