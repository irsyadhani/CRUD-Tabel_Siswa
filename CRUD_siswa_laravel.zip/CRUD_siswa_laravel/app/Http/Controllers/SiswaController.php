<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SiswaController extends Controller
{
    public function index(){
    	//mengambil data dai tabel siswa
    	$siswa = DB::table('siswa')->paginate(10);

    	//mengirim data siswa ke view index
    	return view('index', ['siswa' => $siswa]);
    }
    
    //method untuk menampilkan view form tambah siswa
    public function tambah(){
    	//memanggil view tambah
    	return view('tambah');
    }

    //method untuk insert data ke tabel siswa
    public function store(Request $request){
    	//insert data ke tabel siswa
    	DB::table('siswa')->insert([
    		'nama' => $request->nama,
    		'no_hp' => $request->no_hp,
    		'email' => $request->email,
    	]);
    	//alihkan ke halaman siswa
    	return redirect('/siswa');
    }
    
    // method untuk edit data siswa
	public function edit($id){
		// mengambil data siswa berdasarkan id yang dipilih
		$siswa = DB::table('siswa')->where('id_siswa',$id)->get();
		
		// passing data siswa yang didapat ke view edit.blade.php
		return view('edit',['siswa' => $siswa]);
 
	}

	public function update(Request $request){
		//update data siswa
		DB::table('siswa')->where('id_siswa',$request->id)->update([
			'nama'=>$request->nama,
			'no_hp'=>$request->no_hp,
			'email'=>$request->email
		]);
		//mengalihkan halaman ke index
		return redirect('/siswa');
	}

	//method untuk menghapus
	public function hapus($id){
		//menghapus data siswa berdasarkan id
		DB::table('siswa')->where('id_siswa', $id)->delete();
		//mengalihkan  ke halaman siswa
		return redirect('/siswa');
	}

	public function cari(Request $request){
		//menangkap data pencarian
		$cari = $request->cari;

		//mengambil data dari siswa sesuai dengan pencarian data
		$siswa = DB::table('siswa')
		->where('nama', 'like', "%".$cari."%")
		->paginate();

		//mengirim data ke view index
		return view('index', ['siswa'=>$siswa]);
	}
}
