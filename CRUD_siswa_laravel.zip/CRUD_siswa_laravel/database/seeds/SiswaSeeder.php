<?php

use Illuminate\Database\Seeder;
use Faker\Factory as Faker;

class SiswaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // insert data ke table siswa
        // DB::table('siswa')->insert([
        // 	'nama' => 'Irsyad',
        // 	'no_hp' => '086753198523',
        // 	'email' => 'irsyad@gmail.com'
        // ]);

        $faker = Faker::create('id_ID');

        for($i=1; $i<=20; $i++){
	        // insert data ke table siswa menggunakan faker
	        DB::table('siswa')->insert([
	        	'nama' => $faker->name,
	        	'no_hp' => $faker->phoneNumber,
	        	'email' => $faker->email
	        ]);
    	}
    }
}
