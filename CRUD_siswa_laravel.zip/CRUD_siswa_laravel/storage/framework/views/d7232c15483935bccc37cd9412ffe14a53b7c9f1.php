<!DOCTYPE html>
<html>
<head>
	<title>Edit Data Siswa</title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/app.css')); ?>">
	<script type="text/javascript" src="<?php echo e(asset('/js/app.js')); ?>"></script>
</head>
<body>

	<div class="container" id="content_sidebar">
		<div class="card">
			<div class="card-body">	
				
				<h3 class="text-center">Edit Data Siswa</h3>

				<br>
				<br>

				<?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<form action="/siswa/update" method="post" class="form-horizontal">
						<?php echo e(csrf_field()); ?>

						<input type="hidden" name="id" value="<?php echo e($s->id_siswa); ?>"><br>
						
						<div class="form-group">
							<label class="control-label col-sm-2" for="nama">Nama Siswa:</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" required="required" name="nama" value="<?php echo e($s->nama); ?>">
							</div>
						</div>

						<div class="form-group">
							<label class="control-label col-sm-2" for="nama">Nomor HP:</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" required="required" name="no_hp" value="<?php echo e($s->no_hp); ?>">
							</div>
						</div>

						<div class="form-group">
							<label class="control-label col-sm-2" for="nama">Email:</label>
							<div class="col-sm-10">
								<input type="email" class="form-control" required="required" name="email" value="<?php echo e($s->email); ?>">
							</div>
						</div>
						
						<button type="submit" class="btn btn-primary">Simpan</button>
						<a href="/siswa"><button type="button" class="btn btn-danger">Kembali</button></a>
					</form>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>	
	</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\CRUD_siswa_laravel\resources\views/edit.blade.php ENDPATH**/ ?>